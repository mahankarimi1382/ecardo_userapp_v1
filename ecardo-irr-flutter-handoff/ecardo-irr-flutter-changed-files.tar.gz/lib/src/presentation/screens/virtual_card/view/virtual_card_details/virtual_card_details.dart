import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:qunzo_user/l10n/app_localizations.dart';
import 'package:qunzo_user/src/app/routes/routes.dart';
import 'package:qunzo_user/src/common/widgets/common_loading.dart';
import 'package:qunzo_user/src/presentation/screens/virtual_card/controller/virtual_card_details_controller.dart';
import 'package:qunzo_user/src/presentation/screens/virtual_card/view/virtual_card_details/sub_sections/provider/bsicards/bsicards_card_top_up_bottom_sheet.dart';
import 'package:qunzo_user/src/presentation/screens/virtual_card/view/virtual_card_details/sub_sections/provider/bsicards/bsicards_provider.dart';
import 'package:qunzo_user/src/presentation/screens/virtual_card/view/virtual_card_details/sub_sections/provider/stripe/stripe_card_top_up_bottom_sheet.dart';
import 'package:qunzo_user/src/presentation/screens/virtual_card/view/virtual_card_details/sub_sections/provider/stripe/stripe_provider.dart';
import 'package:qunzo_user/src/presentation/screens/virtual_card/view/virtual_card_details/sub_sections/provider/generic/generic_card_provider.dart';

import '../../../../../app/constants/app_colors.dart';
import '../../../../../app/constants/assets_path/png/png_assets.dart';
import '../../../../../common/widgets/app_bar/common_app_bar.dart';
import '../../../../../common/widgets/app_bar/common_default_app_bar.dart';

class VirtualCardDetails extends StatefulWidget {
  const VirtualCardDetails({super.key});

  @override
  State<VirtualCardDetails> createState() => _VirtualCardDetailsState();
}

class _VirtualCardDetailsState extends State<VirtualCardDetails> {
  final VirtualCardDetailsController controller = Get.find();
  final String id = Get.arguments?["id"] ?? "";
  final String cardId = Get.arguments?["card_id"] ?? "";
  final String initialProvider = (Get.arguments?["provider"] ?? "")
      .toString()
      .toLowerCase();

  Future<void> _fetchCardDetailsByProvider() {
    if (initialProvider == "bsicards") {
      return controller.fetchVirtualCardDetailsBsiCardProvider(cardId: id);
    }

    return controller.fetchVirtualCardDetails(cardId: id);
  }

  @override
  void initState() {
    super.initState();
    _fetchCardDetailsByProvider();
  }

  @override
  Widget build(BuildContext context) {
    final localization = AppLocalizations.of(context);

    return Obx(() {
      final fetchedProvider =
          controller.virtualCardDetailsModel.value.data?.provider
              ?.toLowerCase() ??
          "";
      final provider = initialProvider.isNotEmpty
          ? initialProvider
          : fetchedProvider;

      return Scaffold(
        appBar: const CommonDefaultAppBar(),
        body: Column(
          children: [
            SizedBox(height: 16.h),
            CommonAppBar(
              title: localization!.virtualCardDetailsAppBarTitle,
              rightSideWidget: controller.virtualCardDetailsModel.value.data
                          ?.capabilities?.canViewTransactions ==
                      false
                  ? const SizedBox.shrink()
                  : GestureDetector(
                onTap: () {
                  Get.toNamed(
                    BaseRoute.virtualCardTransaction,
                    arguments: {"card_id": cardId},
                  );
                },
                child: Padding(
                  padding: EdgeInsetsDirectional.only(end: 18.w),
                  child: Image.asset(PngAssets.commonHistoryIcon, width: 30.w),
                ),
              ),
            ),
            Expanded(
              child: controller.isLoading.value
                  ? const CommonLoading()
                  : RefreshIndicator(
                      onRefresh: _fetchCardDetailsByProvider,
                      color: AppColors.lightPrimary,
                      child: SingleChildScrollView(
                        padding: EdgeInsets.symmetric(horizontal: 18.w),
                        physics: const AlwaysScrollableScrollPhysics(),
                        child: provider == "stripe"
                            ? const StripeProvider()
                            : provider == "bsicards"
                            ? const BsicardsProvider()
                            : const GenericCardProvider(),
                      ),
                    ),
            ),
          ],
        ),
        floatingActionButton:
            controller.isLoading.value ||
                controller.virtualCardDetailsModel.value.data?.capabilities
                        ?.canTopup ==
                    false
            ? null
            : Padding(
                padding: EdgeInsets.only(bottom: 20.h),
                child: SizedBox(
                  height: 40.h,
                  width: 120.w,
                  child: FloatingActionButton(
                    heroTag: null,
                    elevation: 0,
                    onPressed: () {
                      if (provider == "stripe") {
                        Get.bottomSheet(StripeCardTopUpBottomSheet(cardId: id));
                      } else if (provider == "bsicards") {
                        Get.bottomSheet(BsicardsCardTopUpBottomSheet());
                      } else {
                        Get.bottomSheet(
                          _GenericTopUpSheet(
                            cardId: id,
                            endpoint: controller
                                .virtualCardDetailsModel
                                .value
                                .data
                                ?.actions
                                ?.topupEndpoint,
                          ),
                        );
                      }
                    },
                    backgroundColor: const Color(0xFF7445FF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Image.asset(PngAssets.addCommonIcon, width: 18.w),
                        SizedBox(width: 4.w),
                        Text(
                          localization.virtualCardDetailsFloatingButton,
                          style: TextStyle(
                            color: AppColors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 13.sp,
                            letterSpacing: 0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
      );
    });
  }
}

class _GenericTopUpSheet extends StatefulWidget {
  final String cardId;
  final String? endpoint;

  const _GenericTopUpSheet({required this.cardId, required this.endpoint});

  @override
  State<_GenericTopUpSheet> createState() => _GenericTopUpSheetState();
}

class _GenericTopUpSheetState extends State<_GenericTopUpSheet> {
  final amountController = TextEditingController();
  String fundingSource = 'irr_wallet';
  int? gatewayMethodId;

  @override
  void dispose() {
    amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<VirtualCardDetailsController>();
    final funding = controller.virtualCardDetailsModel.value.data?.funding;
    fundingSource = funding?.defaultSource ?? fundingSource;
    gatewayMethodId ??= funding?.defaultGatewayMethodId;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Top up amount (IRR)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            if (funding?.mode == 'both')
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'irr_wallet', label: Text('IRR Wallet')),
                  ButtonSegment(value: 'gateway', label: Text('Shetab')),
                ],
                selected: {fundingSource},
                onSelectionChanged: (values) {
                  setState(() => fundingSource = values.first);
                },
              ),
            if (fundingSource == 'gateway') ...[
              const SizedBox(height: 16),
              DropdownButtonFormField<int>(
                value: gatewayMethodId,
                decoration: const InputDecoration(
                  labelText: 'Shetab gateway',
                  border: OutlineInputBorder(),
                ),
                items: (funding?.gateways ?? [])
                    .map(
                      (gateway) => DropdownMenuItem(
                        value: gateway.id,
                        child: Text(gateway.name ?? ''),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  setState(() => gatewayMethodId = value);
                },
              ),
            ],
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                controller.amountController.text = amountController.text;
                controller.cardBalanceTopUp(
                  cardId: widget.cardId,
                  endpoint: widget.endpoint,
                  additionalData: {
                    'funding_source': fundingSource,
                    if (fundingSource == 'gateway')
                      'gateway_method_id': gatewayMethodId,
                  },
                );
              },
              child: const Text('Continue'),
            ),
          ],
        ),
      ),
    );
  }
}
