import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:qunzo_user/src/app/constants/app_colors.dart';
import 'package:qunzo_user/src/common/widgets/button/common_button.dart';
import 'package:qunzo_user/src/presentation/screens/virtual_card/controller/create_virtual_card_controller.dart';

class IrrCardOrderSection extends StatelessWidget {
  const IrrCardOrderSection({super.key});

  @override
  Widget build(BuildContext context) {
    final CreateVirtualCardController controller = Get.find();

    return Obx(() {
      final product = controller.selectedCardProduct.value;
      if (product == null) return const SizedBox.shrink();
      final capabilities = product.capabilities;

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            product.name ?? 'IRR Card',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'Issue fee: ${product.creationFee ?? 0} IRR',
            style: const TextStyle(color: AppColors.error),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: controller.amountController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Initial load (IRR)',
              helperText:
                  '${product.minimumInitialLoad} - ${product.maximumInitialLoad} IRR',
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          ...(product.applicationFields ?? []).map((field) {
            final controller =
                Get.find<CreateVirtualCardController>()
                    .applicationFieldControllers[field.name];
            return Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: TextField(
                controller: controller,
                keyboardType: field.type == 'number'
                    ? TextInputType.number
                    : field.type == 'date'
                    ? TextInputType.datetime
                    : TextInputType.text,
                decoration: InputDecoration(
                  labelText:
                      '${field.label ?? field.name ?? ''}${field.required ? ' *' : ''}',
                  border: const OutlineInputBorder(),
                ),
              ),
            );
          }),
          if (capabilities?.canFundFromIrrWallet == true &&
              capabilities?.canFundFromGateway == true)
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'irr_wallet', label: Text('IRR Wallet')),
                ButtonSegment(value: 'gateway', label: Text('Shetab')),
              ],
              selected: {controller.fundingSource.value},
              onSelectionChanged: (values) {
                controller.fundingSource.value = values.first;
              },
            ),
          const SizedBox(height: 16),
          if (controller.fundingSource.value == 'irr_wallet')
            DropdownButtonFormField<int>(
              value: controller.selectedIrrWallet.value?.id,
              decoration: const InputDecoration(
                labelText: 'IRR wallet',
                border: OutlineInputBorder(),
              ),
              items: controller.irrWallets
                  .map(
                    (wallet) => DropdownMenuItem(
                      value: wallet.id,
                      child: Text(
                        '${wallet.name ?? 'IRR'} - ${wallet.formattedBalance ?? wallet.balance}',
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (id) {
                controller.selectedIrrWallet.value = controller.irrWallets
                    .firstWhereOrNull((wallet) => wallet.id == id);
              },
            ),
          if (controller.fundingSource.value == 'gateway')
            DropdownButtonFormField<int>(
              value: controller.selectedGateway.value?.id,
              decoration: const InputDecoration(
                labelText: 'Shetab gateway',
                border: OutlineInputBorder(),
              ),
              items: (product.gateways ?? [])
                  .map(
                    (gateway) => DropdownMenuItem(
                      value: gateway.id,
                      child: Text(gateway.name ?? gateway.gatewayCode ?? ''),
                    ),
                  )
                  .toList(),
              onChanged: (id) {
                controller.selectedGateway.value = product.gateways
                    ?.firstWhereOrNull((gateway) => gateway.id == id);
              },
            ),
          if (capabilities?.canRequestPhysical == true) ...[
            const SizedBox(height: 8),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              value: controller.requestPhysical.value,
              title: Text(
                'Request physical card (${product.physicalCardFee ?? 0} IRR)',
              ),
              onChanged: (value) {
                controller.requestPhysical.value = value == true;
              },
            ),
          ],
          if ((product.terms ?? '').isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(product.terms!, style: const TextStyle(fontSize: 12)),
          ],
          const SizedBox(height: 20),
          CommonButton(
            width: double.infinity,
            text: 'Create IRR Card',
            isLoading: controller.isCreateVirtualCardLoading.value,
            onPressed: controller.createIrrCard,
          ),
          const SizedBox(height: 30),
        ],
      );
    });
  }
}
