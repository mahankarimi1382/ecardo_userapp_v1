class CardProductModel {
  String? status;
  List<CardProductData>? data;

  CardProductModel({this.status, this.data});

  CardProductModel.fromJson(Map<String, dynamic> json) {
    status = json['status']?.toString();
    if (json['data'] != null) {
      data = <CardProductData>[];
      for (final item in json['data']) {
        data!.add(CardProductData.fromJson(item));
      }
    }
  }
}

class CardProductData {
  int? id;
  String? name;
  String? code;
  String? currency;
  String? fundingMode;
  int? minimumInitialLoad;
  int? maximumInitialLoad;
  int? creationFee;
  int? physicalCardFee;
  String? terms;
  List<CardGatewayData>? gateways;
  CardCapabilities? capabilities;
  List<CardApplicationField>? applicationFields;

  CardProductData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    code = json['code'];
    currency = json['currency'];
    fundingMode = json['funding_mode'];
    minimumInitialLoad = _asInt(json['minimum_initial_load']);
    maximumInitialLoad = _asInt(json['maximum_initial_load']);
    creationFee = _asInt(json['creation_fee']);
    physicalCardFee = _asInt(json['physical_card_fee']);
    terms = json['terms'];
    if (json['gateways'] != null) {
      gateways = <CardGatewayData>[];
      for (final item in json['gateways']) {
        gateways!.add(CardGatewayData.fromJson(item));
      }
    }
    capabilities = json['capabilities'] != null
        ? CardCapabilities.fromJson(json['capabilities'])
        : null;
    if (json['application_fields'] != null) {
      applicationFields = <CardApplicationField>[];
      for (final item in json['application_fields']) {
        applicationFields!.add(CardApplicationField.fromJson(item));
      }
    }
  }

  static int _asInt(dynamic value) =>
      int.tryParse(value?.toString() ?? '') ?? 0;
}

class CardApplicationField {
  String? name;
  String? label;
  String? type;
  bool required = false;

  CardApplicationField.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    label = json['label'];
    type = json['type'];
    required = json['required'] == true;
  }
}

class CardGatewayData {
  int? id;
  String? name;
  String? gatewayCode;
  String? charge;
  String? chargeType;

  CardGatewayData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    gatewayCode = json['gateway_code'];
    charge = json['charge']?.toString();
    chargeType = json['charge_type'];
  }
}

class CardCapabilities {
  bool canCreateVirtual = false;
  bool canRequestPhysical = false;
  bool canFundFromIrrWallet = false;
  bool canFundFromGateway = false;

  CardCapabilities.fromJson(Map<String, dynamic> json) {
    canCreateVirtual = json['can_create_virtual'] == true;
    canRequestPhysical = json['can_request_physical'] == true;
    canFundFromIrrWallet = json['can_fund_from_irr_wallet'] == true;
    canFundFromGateway = json['can_fund_from_gateway'] == true;
  }
}
